package org.example.petmanagement.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PetNameBreedDTO {
    private String name;
    private String animalType;
    private String breed;
}