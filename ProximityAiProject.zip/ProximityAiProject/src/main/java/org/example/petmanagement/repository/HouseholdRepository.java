package org.example.petmanagement.repository;

import com.example.petmanagement.model.Household;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface HouseholdRepository extends JpaRepository<Household, Long> {
    List<Household> findByPetsIsEmpty();
    List<Household> findByOwnerOccupied(boolean ownerOccupied);

    @Query("SELECT COUNT(h) FROM Household h WHERE h.numberOfOccupants = 0")
    Long countEmptyHouses();

    @Query("SELECT COUNT(h) FROM Household h WHERE h.numberOfOccupants = h.maxOccupants")
    Long countFullHouses();
}