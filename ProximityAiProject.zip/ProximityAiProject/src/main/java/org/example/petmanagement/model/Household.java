// Household.java
package org.example.petmanagement.model;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
public class Household {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(min = 1, max = 255)
    @Column(nullable = false, unique = true)
    private String eircode;

    @NotNull
    @Size(min = 1, max = 255)
    @Column(nullable = false)
    private String address;

    @NotNull
    @Size(min = 1, max = 255)
    @Column(nullable = false)
    private String county;

    @NotNull
    @Column(nullable = false)
    private int numberOfOccupants;

    @NotNull
    @Column(nullable = false)
    private int maxOccupants;

    @NotNull
    @Column(nullable = false)
    private boolean ownerOccupied;

    @OneToMany(mappedBy = "household", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Pet> pets = new ArrayList<>();

    @PreRemove
    private void preRemove() {
        pets.clear(); // More efficient than setting each pet's household to null
    }
}
