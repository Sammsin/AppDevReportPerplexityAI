package org.example.petmanagement.service;

import org.example.petmanagement.dto.PetNameBreedDTO;
import org.example.petmanagement.dto.PetStatisticsDTO;
import org.example.petmanagement.repository.PetRepository;
import org.example.petmanagement.model.Pet;
import org.example.petmanagement.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PetService {
    @Autowired
    private PetRepository petRepository;

    @Transactional
    public Pet createPet(Pet pet) {
        return petRepository.save(pet);
    }

    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    public Pet getPetById(Long id) {
        return petRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pet not found with id: " + id));
    }

    @Transactional
    public Pet updatePet(Long id, Pet petDetails) {
        Pet pet = getPetById(id);
        pet.setName(petDetails.getName());
        pet.setAnimalType(petDetails.getAnimalType());
        pet.setBreed(petDetails.getBreed());
        pet.setAge(petDetails.getAge());
        pet.setHousehold(petDetails.getHousehold());
        return petRepository.save(pet);
    }

    @Transactional
    public void deletePet(Long id) {
        Pet pet = getPetById(id);
        petRepository.delete(pet);
    }

    @Transactional
    public int deletePetsByName(String name) {
        return petRepository.deleteByNameIgnoreCase(name);
    }

    public List<Pet> findPetsByAnimalType(String animalType) {
        return petRepository.findByAnimalTypeIgnoreCase(animalType);
    }

    public List<Pet> findPetsByBreed(String breed) {
        return petRepository.findByBreedOrderByAgeAsc(breed);
    }

    public List<PetNameBreedDTO> getPetNameAndBreed() {
        return petRepository.findNameAnimalTypeAndBreed();
    }

    public PetStatisticsDTO getPetStatistics() {
        Double avgAge = petRepository.findAverageAge();
        Integer oldestAge = petRepository.findOldestAge();
        Long totalCount = petRepository.count();
        return new PetStatisticsDTO(avgAge, oldestAge, totalCount);
    }
}
    @Transactional
    public void deletePetsByName(String name) {
        petRepository.deleteByNameIgnoreCase(name);
    }

    public List<Pet> findPetsByAnimalType(String animalType) {
        return petRepository.findByAnimalTypeIgnoreCase(animalType);
    }

    public List<Pet> findPetsByBreed(String breed) {
        return petRepository.findByBreedOrderByAgeAsc(breed);
    }

    public List<PetNameBreedDTO> getPetNameAndBreed() {
        return petRepository.findNameAnimalTypeAndBreed();
    }

    public PetStatisticsDTO getPetStatistics() {
        Double avgAge = petRepository.findAverageAge();
        Integer oldestAge = petRepository.findOldestAge();
        Long totalCount = petRepository.count();
        return new PetStatisticsDTO(avgAge, oldestAge, totalCount);
    }
}