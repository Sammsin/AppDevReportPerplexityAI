// User.java
package org.example.petmanagement.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(min = 1, max = 255)
    @Column(nullable = false, unique = true)
    private String username;

    @NotNull
    @Size(min = 6, max = 255)
    @Column(nullable = false)
    private String password;

    @NotNull
    @Size(min = 1, max = 255)
    @Column(nullable = false)
    private String role;

    @NotNull
    @Column(nullable = false)
    private boolean unlocked;
}