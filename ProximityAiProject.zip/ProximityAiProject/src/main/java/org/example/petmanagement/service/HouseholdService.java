package org.example.petmanagement.service;

import org.example.petmanagement.repository.HouseholdRepository;
import org.example.petmanagement.model.Household;
import org.example.petmanagement.exception.ResourceNotFoundException;
import org.example.petmanagement.exception.ValidationException;
import org.example.petmanagement.dto.HouseholdStatisticsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class HouseholdService {
    @Autowired
    private HouseholdRepository householdRepository;

    @Transactional
    public Household createHousehold(Household household) {
        validateHousehold(household);
        return householdRepository.save(household);
    }

    public List<Household> getAllHouseholds() {
        return householdRepository.findAll();
    }

    public Household getHouseholdById(Long id) {
        return householdRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Household not found with id: " + id));
    }

    @Transactional
    public Household updateHousehold(Long id, Household householdDetails) {
        Household household = getHouseholdById(id);
        validateHousehold(householdDetails);

        household.setEircode(householdDetails.getEircode());
        household.setAddress(householdDetails.getAddress());
        household.setCounty(householdDetails.getCounty());
        household.setNumberOfOccupants(householdDetails.getNumberOfOccupants());
        household.setMaxOccupants(householdDetails.getMaxOccupants());
        household.setOwnerOccupied(householdDetails.isOwnerOccupied());

        return householdRepository.save(household);
    }

    @Transactional
    public void deleteHousehold(Long id) {
        Household household = getHouseholdById(id);
        householdRepository.delete(household);
    }

    public List<Household> getHouseholdsWithNoPets() {
        return householdRepository.findByPetsIsEmpty();
    }

    public List<Household> getOwnerOccupiedHouseholds() {
        return householdRepository.findByOwnerOccupied(true);
    }

    public HouseholdStatisticsDTO getHouseholdStatistics() {
        Long emptyHouses = householdRepository.countEmptyHouses();
        Long fullHouses = householdRepository.countFullHouses();
        return new HouseholdStatisticsDTO(emptyHouses, fullHouses);
    }

    private void validateHousehold(Household household) {
        if (household.getNumberOfOccupants() > household.getMaxOccupants()) {
            throw new ValidationException("Number of occupants cannot be greater than maximum occupants");
        }
    }
}
}