package org.example.petmanagement.repository;

import com.example.petmanagement.model.Pet;
import com.example.petmanagement.dto.PetNameBreedDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface PetRepository extends JpaRepository<Pet, Long> {
    List<Pet> findByAnimalTypeIgnoreCase(String animalType);
    List<Pet> findByBreedOrderByAgeAsc(String breed);

    @Query("DELETE FROM Pet p WHERE LOWER(p.name) = LOWER(:name)")
    int deleteByNameIgnoreCase(@Param("name") String name);

    @Query("SELECT new com.example.petmanagement.dto.PetNameBreedDTO(p.name, p.animalType, p.breed) FROM Pet p")
    List<PetNameBreedDTO> findNameAnimalTypeAndBreed();

    @Query("SELECT COALESCE(AVG(p.age), 0) FROM Pet p")
    Double findAverageAge();

    @Query("SELECT COALESCE(MAX(p.age), 0) FROM Pet p")
    Integer findOldestAge();
}