package org.example.petmanagement.dto;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class PasswordUpdateDTO {
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String newPassword;
}