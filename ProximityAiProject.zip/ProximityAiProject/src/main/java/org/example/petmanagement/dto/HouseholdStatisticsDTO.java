package org.example.petmanagement.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HouseholdStatisticsDTO {
    private Long emptyHouses;
    private Long fullHouses;
}