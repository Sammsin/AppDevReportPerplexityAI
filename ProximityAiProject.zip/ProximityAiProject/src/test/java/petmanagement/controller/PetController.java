package petmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import petmanagement.model.Pet;
import petmanagement.service.PetServiceTest;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pets")
public class PetController {
    @Autowired
    private PetServiceTest petService;

    // 1. Get all the pets
    @GetMapping
    public ResponseEntity<List<Pet>> getAllPets() {
        return ResponseEntity.ok(petService.getAllPets());
    }

    // 4. Get a pet
    @GetMapping("/{id}")
    public ResponseEntity<Pet> getPetById(@PathVariable Long id) {
        return ResponseEntity.ok(petService.getPetById(id));
    }

    // 6. Delete a pet
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deletePet(@PathVariable Long id) {
        petService.deletePet(id);
        return ResponseEntity.ok("Pet deleted successfully");
    }

    // 9. Create a new pet (POST)
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Pet> createPet(@Valid @RequestBody Pet pet) {
        return ResponseEntity.ok(petService.createPet(pet));
    }

    // 10. Change a pet's name (PATCH)
    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<Pet> updatePetName(@PathVariable Long id, @RequestBody Map<String, String> update) {
        String newName = update.get("name");
        if (newName == null || newName.isEmpty()) {
            throw new IllegalArgumentException("Name must be provided");
        }
        Pet updatedPet = petService.updatePetName(id, newName);
        return ResponseEntity.ok(updatedPet);
    }
}