package petmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import petmanagement.model.Household;
import petmanagement.service.HouseholdServiceTest;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/households")
public class HouseholdController {
    @Autowired
    private HouseholdServiceTest householdService;

    // 2. Get all the households
    @GetMapping
    public ResponseEntity<List<Household>> getAllHouseholds() {
        return ResponseEntity.ok(householdService.getAllHouseholds());
    }

    // 3. Get households with no pets
    @GetMapping("/no-pets")
    public ResponseEntity<List<Household>> getHouseholdsWithNoPets() {
        return ResponseEntity.ok(householdService.getHouseholdsWithNoPets());
    }

    // 5. Get a household
    @GetMapping("/{id}")
    public ResponseEntity<Household> getHouseholdById(@PathVariable Long id) {
        return ResponseEntity.ok(householdService.getHouseholdById(id));
    }

    // 7. Delete a household
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deleteHousehold(@PathVariable Long id) {
        householdService.deleteHousehold(id);
        return ResponseEntity.ok("Household deleted successfully");
    }

    // 8. Create a new household (POST)
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Household> createHousehold(@Valid @RequestBody Household household) {
        return ResponseEntity.ok(householdService.createHousehold(household));
    }
}