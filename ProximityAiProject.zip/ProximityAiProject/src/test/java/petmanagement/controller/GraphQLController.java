package petmanagement.controller;

public class GraphQLController {

    @Autowired
    private HouseholdService householdService;

    @Autowired
    private PetService petService;

    @QueryMapping
    public List<Household> getAllHouseholds() {
        return householdService.getAllHouseholds();
    }

    @QueryMapping
    public List<Pet> getPetsByAnimalType(@Argument String animalType) {
        return petService.findPetsByAnimalType(animalType);
    }

    @QueryMapping
    public Household getHousehold(@Argument Long id) {
        return householdService.getHouseholdById(id);
    }

    @QueryMapping
    public Pet getPet(@Argument Long id) {
        return petService.getPetById(id);
    }

    @QueryMapping
    public Statistics getStatistics() {
        PetStatisticsDTO petStats = petService.getPetStatistics();
        HouseholdStatisticsDTO householdStats = householdService.getHouseholdStatistics();

        return new Statistics(
                petStats.getAverageAge(),
                petStats.getOldestAge(),
                petStats.getTotalCount(),
                householdStats.getEmptyHouses(),
                householdStats.getFullHouses()
        );
    }

    @MutationMapping
    public Household createHousehold(@Argument HouseholdInput input) {
        Household household = new Household();
        // Map input fields to household object
        return householdService.createHousehold(household);
    }

    @MutationMapping
    public boolean deleteHousehold(@Argument Long id) {
        householdService.deleteHousehold(id);
        return true;
    }

    @MutationMapping
    public boolean deletePet(@Argument Long id) {
        petService.deletePet(id);
        return true;
    }
}