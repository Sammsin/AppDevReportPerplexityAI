import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

class HouseholdServiceTest {

    @Mock
    private HouseholdRepository householdRepository;

    @InjectMocks
    private HouseholdService householdService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void whenGetAllHouseholds_thenReturnAllHouseholds() {
        // given
        Household household1 = new Household();
        household1.setEircode("A65F4E2");
        Household household2 = new Household();
        household2.setEircode("B78G3H1");
        List<Household> households = Arrays.asList(household1, household2);

        when(householdRepository.findAll()).thenReturn(households);

        // when
        List<Household> found = householdService.getAllHouseholds();

        // then
        assertThat(found).hasSize(2);
        verify(householdRepository, times(1)).findAll();
    }

    @Test
    void whenCreateHousehold_thenReturnCreatedHousehold() {
        // given
        Household household = new Household();
        household.setEircode("A65F4E2");

        when(householdRepository.save(any(Household.class))).thenReturn(household);

        // when
        Household created = householdService.createHousehold(household);

        // then
        assertThat(created.getEircode()).isEqualTo(household.getEircode());
        verify(householdRepository, times(1)).save(household);
    }

    @Test
    void whenUpdateHousehold_thenReturnUpdatedHousehold() {
        // given
        Long id = 1L;
        Household existingHousehold = new Household();
        existingHousehold.setId(id);
        existingHousehold.setEircode("A65F4E2");

        Household updatedHousehold = new Household();
        updatedHousehold.setId(id);
        updatedHousehold.setEircode("B78G3H1");

        when(householdRepository.findById(id)).thenReturn(Optional.of(existingHousehold));
        when(householdRepository.save(any(Household.class))).thenReturn(updatedHousehold);

        // when
        Household result = householdService.updateHousehold(id, updatedHousehold);

        // then
        assertThat(result.getEircode()).isEqualTo(updatedHousehold.getEircode());
        verify(householdRepository, times(1)).findById(id);
        verify(householdRepository, times(1)).save(any(Household.class));
    }

    @Test
    void whenDeleteHousehold_thenDeleteSuccessfully() {
        // given
        Long id = 1L;
        Household household = new Household();
        household.setId(id);

        when(householdRepository.findById(id)).thenReturn(Optional.of(household));

        // when
        householdService.deleteHousehold(id);

        // then
        verify(householdRepository, times(1)).findById(id);
        verify(householdRepository, times(1)).delete(household);
    }
}