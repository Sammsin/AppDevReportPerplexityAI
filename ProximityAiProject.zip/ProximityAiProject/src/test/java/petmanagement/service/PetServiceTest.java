import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

class PetServiceTest {

    @Mock
    private PetRepository petRepository;

    @InjectMocks
    private PetService petService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void whenGetAllPets_thenReturnAllPets() {
        // given
        Pet pet1 = new Pet();
        pet1.setName("Fluffy");
        Pet pet2 = new Pet();
        pet2.setName("Buddy");
        List<Pet> pets = Arrays.asList(pet1, pet2);

        when(petRepository.findAll()).thenReturn(pets);

        // when
        List<Pet> found = petService.getAllPets();

        // then
        assertThat(found).hasSize(2);
        verify(petRepository, times(1)).findAll();
    }

    @Test
    void whenCreatePet_thenReturnCreatedPet() {
        // given
        Pet pet = new Pet();
        pet.setName("Fluffy");

        when(petRepository.save(any(Pet.class))).thenReturn(pet);

        // when
        Pet created = petService.createPet(pet);

        // then
        assertThat(created.getName()).isEqualTo(pet.getName());
        verify(petRepository, times(1)).save(pet);
    }

    @Test
    void whenUpdatePet_thenReturnUpdatedPet() {
        // given
        Long id = 1L;
        Pet existingPet = new Pet();
        existingPet.setId(id);
        existingPet.setName("Fluffy");

        Pet updatedPet = new Pet();
        updatedPet.setId(id);
        updatedPet.setName("Buddy");

        when(petRepository.findById(id)).thenReturn(Optional.of(existingPet));
        when(petRepository.save(any(Pet.class))).thenReturn(updatedPet);

        // when
        Pet result = petService.updatePet(id, updatedPet);

        // then
        assertThat(result.getName()).isEqualTo(updatedPet.getName());
        verify(petRepository, times(1)).findById(id);
        verify(petRepository, times(1)).save(any(Pet.class));
    }

    @Test
    void whenDeletePet_thenDeleteSuccessfully() {
        // given
        Long id = 1L;
        Pet pet = new Pet();
        pet.setId(id);

        when(petRepository.findById(id)).thenReturn(Optional.of(pet));

        // when
        petService.deletePet(id);

        // then
        verify(petRepository, times(1)).findById(id);
        verify(petRepository, times(1)).delete(pet);
    }
}