import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

@DataJpaTest
class PetRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private PetRepository petRepository;

    @Test
    void whenSavePet_thenReturnSavedPet() {
        // given
        Pet pet = new Pet();
        pet.setName("Fluffy");
        pet.setAnimalType("Cat");
        pet.setBreed("Persian");
        pet.setAge(3);

        // when
        Pet savedPet = petRepository.save(pet);

        // then
        assertThat(savedPet).isNotNull();
        assertThat(savedPet.getId()).isNotNull();
        assertThat(savedPet.getName()).isEqualTo("Fluffy");
    }

    @Test
    void whenFindById_thenReturnPet() {
        // given
        Pet pet = new Pet();
        pet.setName("Buddy");
        pet.setAnimalType("Dog");
        pet.setBreed("Labrador");
        pet.setAge(5);
        entityManager.persist(pet);
        entityManager.flush();

        // when
        Optional<Pet> found = petRepository.findById(pet.getId());

        // then
        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo(pet.getName());
    }

    @Test
    void whenFindByAnimalType_thenReturnListOfPets() {
        // given
        Pet pet1 = new Pet();
        pet1.setName("Fluffy");
        pet1.setAnimalType("Cat");
        entityManager.persist(pet1);

        Pet pet2 = new Pet();
        pet2.setName("Whiskers");
        pet2.setAnimalType("Cat");
        entityManager.persist(pet2);

        Pet pet3 = new Pet();
        pet3.setName("Buddy");
        pet3.setAnimalType("Dog");
        entityManager.persist(pet3);

        entityManager.flush();

        // when
        List<Pet> foundPets = petRepository.findByAnimalTypeIgnoreCase("cat");

        // then
        assertThat(foundPets).hasSize(2);
        assertThat(foundPets).extracting(Pet::getName).containsExactlyInAnyOrder("Fluffy", "Whiskers");
    }

    @Test
    void whenDeletePet_thenPetShouldBeRemoved() {
        // given
        Pet pet = new Pet();
        pet.setName("ToDelete");
        pet.setAnimalType("Bird");
        entityManager.persist(pet);
        entityManager.flush();

        // when
        petRepository.delete(pet);
        Optional<Pet> deletedPet = petRepository.findById(pet.getId());

        // then
        assertThat(deletedPet).isEmpty();
    }
}