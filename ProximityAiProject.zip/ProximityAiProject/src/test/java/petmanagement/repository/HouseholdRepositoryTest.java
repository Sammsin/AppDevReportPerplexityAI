package petmanagement.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

@DataJpaTest
class HouseholdRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private HouseholdRepository householdRepository;

    @Test
    void whenSaveHousehold_thenReturnSavedHousehold() {
        // given
        Household household = new Household();
        household.setEircode("A65F4E2");
        household.setAddress("123 Main St");
        household.setCounty("Dublin");
        household.setNumberOfOccupants(3);
        household.setMaxOccupants(5);
        household.setOwnerOccupied(true);

        // when
        Household savedHousehold = householdRepository.save(household);

        // then
        assertThat(savedHousehold).isNotNull();
        assertThat(savedHousehold.getId()).isNotNull();
        assertThat(savedHousehold.getEircode()).isEqualTo("A65F4E2");
    }

    @Test
    void whenFindById_thenReturnHousehold() {
        // given
        Household household = new Household();
        household.setEircode("B78G3H1");
        household.setAddress("456 Elm St");
        household.setCounty("Cork");
        entityManager.persist(household);
        entityManager.flush();

        // when
        Optional<Household> found = householdRepository.findById(household.getId());

        // then
        assertThat(found).isPresent();
        assertThat(found.get().getEircode()).isEqualTo(household.getEircode());
    }

    @Test
    void whenFindByOwnerOccupied_thenReturnListOfHouseholds() {
        // given
        Household household1 = new Household();
        household1.setEircode("C91D2F3");
        household1.setOwnerOccupied(true);
        entityManager.persist(household1);

        Household household2 = new Household();
        household2.setEircode("D14E5G6");
        household2.setOwnerOccupied(true);
        entityManager.persist(household2);

        Household household3 = new Household();
        household3.setEircode("E25F7H8");
        household3.setOwnerOccupied(false);
        entityManager.persist(household3);

        entityManager.flush();

        // when
        List<Household> foundHouseholds = householdRepository.findByOwnerOccupied(true);

        // then
        assertThat(foundHouseholds).hasSize(2);
        assertThat(foundHouseholds).extracting(Household::getEircode).containsExactlyInAnyOrder("C91D2F3", "D14E5G6");
    }

    @Test
    void whenDeleteHousehold_thenHouseholdShouldBeRemoved() {
        // given
        Household household = new Household();
        household.setEircode("F36G8J9");
        household.setAddress("789 Oak St");
        entityManager.persist(household);
        entityManager.flush();

        // when
        householdRepository.delete(household);
        Optional<Household> deletedHousehold = householdRepository.findById(household.getId());

        // then
        assertThat(deletedHousehold).isEmpty();
    }
}